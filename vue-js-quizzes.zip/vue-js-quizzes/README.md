# Vue.js Quizzes

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/dywvVvP/7c2134a08a6198620a202c69968e3477](https://codepen.io/Nalini1998/pen/dywvVvP/7c2134a08a6198620a202c69968e3477).

This is a rebuild of my VueQuiz App that I built earlier. This pen has been created to drop the dependency on bulma css framework and use scss to style independantly.

## Credits

 - Vue
 - Animate.css

## Featured

* https://vuejsexamples.com/a-nice-quiz-app-with-vue/

:)

